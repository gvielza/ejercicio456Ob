package ejercicio4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
