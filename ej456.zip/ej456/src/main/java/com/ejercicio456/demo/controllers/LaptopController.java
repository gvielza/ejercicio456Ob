package com.ejercicio456.demo.controllers;

import com.ejercicio456.demo.entities.Laptop;
import com.ejercicio456.demo.reporitory.LaptopRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class LaptopController {
    @Autowired
    private LaptopRepository repo;
    @GetMapping("/api/ls")
    public List<Laptop> obtenerLaptops(){
        return repo.findAll();
    }
    @PostMapping("/api/new")
    public ResponseEntity<?>agregar(@RequestBody Laptop laptop){
        return ResponseEntity.ok(repo.save(laptop));
            }
}
